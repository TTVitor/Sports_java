package four;

public class AmericanFootball extends Sport {
	
	public AmericanFootball() {
		super();
	}
	
	public void printData() {
		
	}
}
