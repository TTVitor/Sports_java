package four;

import java.util.ArrayList;

public class Team {
	private String name;
	private Sport sport;
	private ArrayList<Player> players;
	
	public Team(String teamName, Sport sport) {
		this.name = teamName;
		this.sport = sport;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public Sport getSport() {
		return sport;
	}
	
	public void setSport(Sport sport) {
		this.sport = sport;
	}
	
	public void addPlayer(Player player) {
		this.players.add(player);
	}
	
	public ArrayList<Player> getPlayers(){
		return this.players;
	}
	
	public void printTeam() {
		System.out.println("---------TEAM DATA---------");
		System.out.println("Name do time: " +getName());
		System.out.println("Nome do esporte: " +getSport());
		for(Player player: getPlayers()) {
			player.printPlayer();
		}
	}
}