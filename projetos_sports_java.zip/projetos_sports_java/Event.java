package four;

import java.util.ArrayList;

public class Event {
	private String name;
	private String place;
	private String date;
	private ArrayList<Team> teams;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPlace() {
		return place;
	}
	
	public void setPlace(String place) {
		this.place = place;
	}
	
	public String getDate() {
		return date;
	}
	
	public void setDate(String date) {
		this.date = date;
	}
	
	public ArrayList<Team> getTeams() {
		return teams;
	}
	
	public void addTeam(Team team) {
		this.teams.add(team);
	}
	
	public Team getTeamByName(String name) {
		for(Team team: getTeams()) {
			if(team.getName().equals(name))
				return team;
		}
		return null;
	}
	
	public void printEvent() {
		System.out.println("------EVENT DATA------");
		System.out.println("Nome do evento: " +getName());
		System.out.println("Local do evento: " +getPlace());
		System.out.println("Data do evento: " +getDate());
		for(Team team: getTeams()) {
			team.printTeam();
		}
	}
}