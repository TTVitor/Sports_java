package four;

public class Basketball extends Sport {
	
	public Basketball() {
		super();
	}
	
	public void printData() {
		
	}

}
